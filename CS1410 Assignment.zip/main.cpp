// Author: Jameson Aranda
// Assignment: $safeprojectname$
// Instructor: Craig Sharp
// Class: CS 1410 -- 002
// Date Written: $time$
// Description: 

// I declare that the following code was written by me or provided
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive 
// a zero on this project if I am found in violation of this policy.

// Function Name: 
// Purpose: 
// Parameters: 
// Returns: 
// Pre-conditions: 
// Post-conditions: 

#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>

using namespace std;

int main()
{
	return 0;
}

