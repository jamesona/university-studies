﻿// Author: Jameson Aranda
// Assignment: Lab 8
// Instructor: Timothy Stanley
// Class: CS 1400-004
// Date Written: 1/31/16
// Description: Farmer John pseudo code

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8
{
    class Program
    {
        static void Main(string[] args)
        {
            // prompt user for radius
            // set double radius equal to user input
            //
            // area of square is equal to (2 * r) * (2 * r) squared
            //
            // area of circle is equal to (pi * r * r)
            //
            // unwatered area is equal to squareArea - circleArea

            Console.ReadKey(true);
        }
    }
}
